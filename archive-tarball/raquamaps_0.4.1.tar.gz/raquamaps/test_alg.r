# require("raquamaps")
require("dplyr")
require("reshape2")
require("raster")
require("rgbif")
require("ggplot2")

# raquamaps::which_cells

require("raquamaps")

# cat(stringi::stri_escape_unicode("ö"))

which_cells(.latinname = "galemys pyrenaicus")

calc_spreads_by_species(s)

species_list <- default_species_list()

# calculate spreads for species with 
# presence in more than 100 half-degree cells
s <- 
  species_list %>% 
  filter(count > 100) %>%
  group_by(species) %>%
  do(calc_spreads_by_species(.$species))

# calculate model for all species
p <- 
  species_list %>% 
  # filter(count > 10) %>%
  group_by(species) %>%
  do(calc_probs_by_species(.$species))  

p %>% 
  summarise(count = n_distinct(loiczid)) %>%
  arrange(desc(count))

export_am_csv(p)


require("raster")
o <- presence_rgbif()
r <- rasterize_presence(o)

r2 <- crop(r, extent(-10, 10, 40, 50))

plot_am_raster(r2)

require("ggplot2")
qplot(data = o, x = decimalLongitude, y = decimalLatitude)

# how to convert to the right projections
# http://www.r-bloggers.com/plot-maps-like-a-boss/
  
install.packages("OpenStreetMap")
install.packages("rgdal")

install.packages("rMaps")

#export_am_raster(p)

# have datasets with loiczid sets for various companies or other 
# geographical areas of interest

# then it is time to run the probability calculations / model
# for larger areas - like Europe or the full range of all of the world

# TODO NEXT


# which license should we use? 

# ask Karin about whether we can commit to maintain the package in the future and in other projects...

# UPPMAX account



# calc probs only for cells in the habitat ie basin

# now for loiczid cells, create raster 

require("googleVis")
df <- spreadz[[1]] %.% 
  filter(Measure == "Elevation") %.% 
  select(Measure, min, d1, d9, max)
require("reshape2")
df <- melt(df)
df <- reshape2::dcast(df, variable ~ Measure, sum)
linechart <- googleVis::gvisLineChart(df, xvar = "variable")
plot(linechart)

# plot envelope per var as trapezoid curve googlevis

# shiny interactive chg of envelope using sliders
# followed by adjust_spread validation

# shiny map of raster


