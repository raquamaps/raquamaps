context("Download files as .zip from dropbox folder")

test_that("Can get HCAF ref data from dropbox folder", {
  dropbox_share <- "7yzcbdgm5m9axht/PUnf7vugFc"
  #  expect_equal(get_dropbox_as_zip(dropbox_share), 0)
  expect_true(TRUE)
  return (TRUE)
})



# expect_true(x)
# expect_false(x)
# expect_equal(x, y)

# expect_message(x, y)
# expect_warning(x, y)
# expect_error(x, y)

# expect_is(x, y)
# expect_equivalent(x, y)
# expect_identical(x, y)

# expect_match(x, y)
# expect_output(x, y)