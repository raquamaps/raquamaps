library("raquamaps")
library("testthat")
test_check("raquamaps")